exports.id = 256;
exports.ids = [256];
exports.modules = {

/***/ 1247:
/***/ ((module) => {

// Exports
module.exports = {
	"hero": "About_hero__l6ad9",
	"rain": "About_rain__3TA1k",
	"content": "About_content___JqsF",
	"text": "About_text__8HiPf",
	"button": "About_button__khFxw"
};


/***/ }),

/***/ 2256:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_About_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1247);
/* harmony import */ var _styles_About_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_About_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);



const Row = ({ index , space , codeDropSize  })=>{
    const rowLength = 33;
    const initialisePotentialDigits = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        const array = [];
        for(let i = 0; i < space + codeDropSize; i++){
            if (i < space) {
                array.push(" ");
            } else {
                array.push(i % 9);
            }
        }
        return array;
    }, [
        codeDropSize,
        space
    ]);
    const initialiseRows = (num)=>{
        const potentialDigits = initialisePotentialDigits();
        const array = [];
        for(let i = 0; i < rowLength; i++){
            const potentialDigitsIndex = (num + i) % potentialDigits.length;
            array.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                children: potentialDigits[potentialDigitsIndex]
            }, i));
        }
        return array;
    };
    const [digit, setDigit] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(0);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const intervalId = setInterval(()=>{
            setDigit((prevDigit)=>prevDigit === 0 ? initialisePotentialDigits().length - 1 : prevDigit - 1);
        }, 150);
        return ()=>clearInterval(intervalId);
    }, [
        initialisePotentialDigits
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
        className: (_styles_About_module_css__WEBPACK_IMPORTED_MODULE_2___default().rain),
        style: {
            marginLeft: `${index * 2}vw`
        },
        children: initialiseRows(digit)
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Row);


/***/ })

};
;