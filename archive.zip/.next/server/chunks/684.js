"use strict";
exports.id = 684;
exports.ids = [684];
exports.modules = {

/***/ 6684:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ChessPieces": () => (/* binding */ ChessPieces),
  "default": () => (/* binding */ chess_Piece)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@dnd-kit/core"
var core_ = __webpack_require__(3831);
// EXTERNAL MODULE: ./src/styles/ChessBoard.module.css
var ChessBoard_module = __webpack_require__(1099);
var ChessBoard_module_default = /*#__PURE__*/__webpack_require__.n(ChessBoard_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/images/pieces/white-pawn.png
/* harmony default export */ const white_pawn = ({"src":"/_next/static/media/white-pawn.25b05771.png","height":68,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAaElEQVR42i3HsQ2AIBBG4ad2TmKpjY1jSNzDRRzAVax0AULDBFLQEAYgOSH4XXL5H8Xb/r+6WjjVudYFDYDxxlPr6EAtUaKohVJ7B8xOnDBTC/Qjmb5BGoDBSkghWWGg2HomxnzT1sMHxhslP2f/eXsAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/images/pieces/white-knight.png
/* harmony default export */ const white_knight = ({"src":"/_next/static/media/white-knight.2e8fb83a.png","height":68,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAiElEQVR42hXHIQ8BYQDH4d/7+gA2TZUYn0KVfAUBwXZJuixcJ5yo2BXFNUFz6iXBTBQwjM3ecPvf3dMeIiJ7YoSQwQAr6+ENF8tel5IBqK7fTk/tNpSNiYO/Xro5p/kYoLbPvpqG14+UbAFsMGNwCFU4p8DR+vj9ix6/u5KUCk0jM6nTpkWHBuRswzgGPxKMPQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/images/pieces/white-bishop.png
/* harmony default export */ const white_bishop = ({"src":"/_next/static/media/white-bishop.d8e293f9.png","height":68,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAf0lEQVR42mOAgFauVi4GGFjLysDQ0NTQBGExtDMxMLhqHnt79K2zJgNDGxPDfxYGhjPrn/1/9v/MegYQbwcLA8P88jv/7/yfX87AsJ2FYTEzA4Nd9Mb/G//bRjOAeSzp1VVbpjyc8rBqS3o1AwsDA2uoYYWam7CbcIVaqCEDKwAXxSnpRsVp5AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/images/pieces/white-rook.png
/* harmony default export */ const white_rook = ({"src":"/_next/static/media/white-rook.5b687dc7.png","height":68,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAeElEQVR42k3HoQ2DQABG4UdyYxD8GRyaNVAgwLEAnmDbCQgJAsEADcHiMMxSA+7+9lC8pz5eAY/eXk3UVl3WZW3VRPgS2+vzv1diAWdgnU6dWieQ4WtgG5yctgEvBTDuhw6NO7co8lnLtVyzihxfHZZxalNbxnUIPzhFMicHUrP6AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/images/pieces/white-queen.png
/* harmony default export */ const white_queen = ({"src":"/_next/static/media/white-queen.b5f7e8d7.png","height":68,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAfklEQVR42mOAgAzeDF4GCChWK7OuqsrPyc+pqiqzLlZjKAgLaWSIs890yGSIC2ksCGNgYKia1ndwwZUFV/oOVk4Da5o0YeP/vf/2/Fv/f+IEBjBQ2fzn2P9j/zf/YVAB8zX1jn6+/+3+t6OfNfXAAuGsDNJMqkyqDNLhrAwMAHSALU8Q6g8AAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/images/pieces/white-king.png
/* harmony default export */ const white_king = ({"src":"/_next/static/media/white-king.cc7f6c65.png","height":68,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAeUlEQVR42h3HrQ2DUBiF4ZefBCQDILpAa9Edqh2ABIPonaHFonsXwKEggQlYgYQEcfhyn2POC9SxS9qszVxSx4CLwDxt5hPqRtV3fUdlzxTLtmu07Vo2CsinWVrP9ZSmmRxT/g6vv74HJaAIGj9oUONDBen7/nqQAlxivi5g6Ccy7AAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/images/pieces/black-pawn.png
/* harmony default export */ const black_pawn = ({"src":"/_next/static/media/black-pawn.fea13c93.png","height":68,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAS0lEQVR42kWMsQ2AMBDEDHSZJCVp0mQMWBi2YQek5HTKK2fpJbt4vD3u0psr0ub4iWkH0OiigcyhOlQH73V44kGW/KKT8RKFUxQSDEcOEAxBPRbfAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/images/pieces/black-knight.png
/* harmony default export */ const black_knight = ({"src":"/_next/static/media/black-knight.e3fe9f55.png","height":68,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAf0lEQVR42mNgYGBgYoAAxrOMMG4aw6zJTgwMDAx7wEL8VR8Y/mf/37GOgZEBDDp9/iv8Z/hZ839fBgMDA4NQxF+G/wwzGT5a/9+4GWyGcqtkEuNMhv+K/1deZGBgUGJiYGAIZPzP8EX8/9KLeswMDIxejAySjNoMmvI6E5QZGAA9iiIAnAcXNgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/images/pieces/black-bishop.png
/* harmony default export */ const black_bishop = ({"src":"/_next/static/media/black-bishop.bc58c77b.png","height":68,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAbUlEQVR42j2HsQmAMBAAD01AtNQZBEsLB7ARBDdwD1PY2eoa2qbJQg6QGd6EgHfNHYmpnEp+NHAEU1UZ0C1+8XTpFGA32QRLvFnBYIwYGQzx7hzO9ZJLzhWecErvON6gC6UoNH3TjvVYNy19oT+4DRm4d8TJFQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/images/pieces/black-rook.png
/* harmony default export */ const black_rook = ({"src":"/_next/static/media/black-rook.d1a9d62e.png","height":68,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAZklEQVR42k2HoQ2AMBQFj4QFSpAkWDDsQUJCJaqKhAXQHYAlMEzDQpWP3yruzB2u4ke5pmdnM3erjB9ORfPUOgBzDcvj5bU85doauJF5k08VxPfSpfhSDheCjnSkIBcodEyM5kQHH5UiIC6HLoP2AAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/images/pieces/black-queen.png
/* harmony default export */ const black_queen = ({"src":"/_next/static/media/black-queen.457a3bd3.png","height":68,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAdUlEQVR42mOAAl4ghAI1BmuGKoYcIKxisAbyGMKYGuXjlDOVM+XjmBoZwhiAYBrDQYYrQHgQyAIB1QlR/0uAMOq/6gQGEOhQnftrwt8Jf+f+6lBlAIGZ+ov+zfo/6/+ifzP1GUBgPutyvXXB64KX681nZWAAAKndJl20HD8WAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/images/pieces/black-king.png
/* harmony default export */ const black_king = ({"src":"/_next/static/media/black-king.aa56eaf8.png","height":68,"width":68,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAg0lEQVR42g3MoQ2DQABG4VcgAYlAIBAs0Fo0yzACA3QADCQIJIa06dlzra7AMAMSPAni5/LUMx9i8KyfhElo/cET/G9CpGVaCrlDmHwuGBnnwuSCLW7WSk9XpWbdYxR1C2rP9kTdogjxyz7HpEnm+GaCt0N7W6tWb8XLoS4C7jwIhLgA7oM+MM9UU50AAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/pages/projects/chess/Piece.tsx

















var ChessPieces;
(function(ChessPieces) {
    ChessPieces[ChessPieces["Empty"] = 0] = "Empty";
    ChessPieces[ChessPieces["WhitePawn"] = 1] = "WhitePawn";
    ChessPieces[ChessPieces["WhiteKnight"] = 2] = "WhiteKnight";
    ChessPieces[ChessPieces["WhiteBishop"] = 3] = "WhiteBishop";
    ChessPieces[ChessPieces["WhiteRook"] = 4] = "WhiteRook";
    ChessPieces[ChessPieces["WhiteQueen"] = 5] = "WhiteQueen";
    ChessPieces[ChessPieces["WhiteKing"] = 6] = "WhiteKing";
    ChessPieces[ChessPieces["BlackPawn"] = 7] = "BlackPawn";
    ChessPieces[ChessPieces["BlackKnight"] = 8] = "BlackKnight";
    ChessPieces[ChessPieces["BlackBishop"] = 9] = "BlackBishop";
    ChessPieces[ChessPieces["BlackRook"] = 10] = "BlackRook";
    ChessPieces[ChessPieces["BlackQueen"] = 11] = "BlackQueen";
    ChessPieces[ChessPieces["BlackKing"] = 12] = "BlackKing";
})(ChessPieces || (ChessPieces = {}));
const Piece = ({ id , type  })=>{
    const [image, setImage] = (0,external_react_.useState)(()=>{
        switch(type){
            case ChessPieces.WhitePawn:
                return white_pawn.src;
            case ChessPieces.WhiteKnight:
                return white_knight.src;
            case ChessPieces.WhiteBishop:
                return white_bishop.src;
            case ChessPieces.WhiteRook:
                return white_rook.src;
            case ChessPieces.WhiteQueen:
                return white_queen.src;
            case ChessPieces.WhiteKing:
                return white_king.src;
            case ChessPieces.BlackPawn:
                return black_pawn.src;
            case ChessPieces.BlackKnight:
                return black_knight.src;
            case ChessPieces.BlackBishop:
                return black_bishop.src;
            case ChessPieces.BlackRook:
                return black_rook.src;
            case ChessPieces.BlackQueen:
                return black_queen.src;
            case ChessPieces.BlackKing:
                return black_king.src;
            default:
                return "";
        }
    });
    const { attributes , listeners , setNodeRef , transform  } = (0,core_.useDraggable)({
        id
    });
    const style = transform ? {
        transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`
    } : undefined;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: setNodeRef,
        style: style,
        ...listeners,
        ...attributes,
        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
            src: image,
            alt: "White Pawn",
            className: (ChessBoard_module_default())["piece-image"],
            width: "100",
            height: "100"
        })
    });
};
/* harmony default export */ const chess_Piece = (Piece);


/***/ })

};
;