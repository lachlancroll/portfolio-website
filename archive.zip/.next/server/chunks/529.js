"use strict";
exports.id = 529;
exports.ids = [529];
exports.modules = {

/***/ 3529:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _dnd_kit_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3831);
/* harmony import */ var _dnd_kit_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_dnd_kit_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Droppable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5345);
/* harmony import */ var _Piece__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6684);
/* harmony import */ var _styles_ChessBoard_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1099);
/* harmony import */ var _styles_ChessBoard_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_ChessBoard_module_css__WEBPACK_IMPORTED_MODULE_5__);






const ChessBoard = ()=>{
    const [board, setBoard] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [isFirstMove, setIsFirstMove] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const findRow = (index)=>{
        return Math.floor(index / 8);
    };
    const findCol = (index)=>{
        return index % 8;
    };
    async function move(numbers, prevPos, newPos) {
        try {
            const response = await fetch(`http://chessbackend-env-1.eba-fgpqpn4v.ap-southeast-2.elasticbeanstalk.com/api/m1?numbers=${numbers}`);
            const rT = await response.text();
            const arr = rT.split(" ").map(Number);
            setBoard((prevBoard)=>{
                const newRow = findRow(newPos);
                const newCol = findCol(newPos);
                const prevRow = findRow(prevPos);
                const prevCol = findCol(prevPos);
                const newBoard = prevBoard.map((row)=>row.map((square)=>({
                            ...square,
                            isHighlighted: false
                        })));
                if (arr[1] === 99) {
                    return newBoard;
                }
                newBoard[newRow][newCol] = {
                    ...newBoard[newRow][newCol],
                    piece: newBoard[prevRow][prevCol].piece
                };
                newBoard[prevRow][prevCol] = {
                    ...newBoard[prevRow][prevCol],
                    piece: _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.Empty
                };
                const opponentNewRow = findRow(arr[2]);
                const opponentNewCol = findCol(arr[2]);
                const oppenentPrevRow = findRow(arr[1]);
                const oppenentPrevCol = findCol(arr[1]);
                console.log(arr);
                newBoard[opponentNewRow][opponentNewCol] = {
                    ...newBoard[opponentNewRow][opponentNewCol],
                    piece: newBoard[oppenentPrevRow][oppenentPrevCol].piece
                };
                newBoard[oppenentPrevRow][oppenentPrevCol] = {
                    ...newBoard[oppenentPrevRow][oppenentPrevCol],
                    piece: _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.Empty
                };
                return newBoard;
            });
        } catch (error) {
            console.error(error);
        }
    }
    const showLegalMoves = async (prevPositionString)=>{
        try {
            const response = await fetch(`http://chessbackend-env-1.eba-fgpqpn4v.ap-southeast-2.elasticbeanstalk.com/api/m2?number=${prevPositionString}`);
            const legalMoves = (await response.text()).slice(0, -1).split(" ").map(Number);
            setBoard((prevBoard)=>{
                const newBoard = [
                    ...prevBoard
                ];
                legalMoves.forEach((num)=>{
                    const newRow = findRow(num);
                    const newCol = findCol(num);
                    newBoard[newRow][newCol] = {
                        ...newBoard[newRow][newCol],
                        isHighlighted: true
                    };
                });
                return newBoard;
            });
        } catch (error) {
            console.error(error);
        }
    };
    const handleDragStart = (event)=>{
        const prevPosition = event.active.id;
        let prevPositionString = prevPosition.toString();
        showLegalMoves(prevPositionString);
    };
    const handleDragEnd = (event)=>{
        const { active , over  } = event;
        const { id: newId  } = over || {};
        const { id: prevId  } = active || {};
        if (typeof newId === "number" && typeof prevId === "number") {
            let firstMoveNumber = isFirstMove ? 1 : 0;
            const nums = prevId + " " + newId + " " + firstMoveNumber;
            isFirstMove && setIsFirstMove(false);
            move(nums, prevId, newId);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const squares = [];
        for(let row = 0; row < 8; row++){
            const newRow = [];
            for(let col = 0; col < 8; col++){
                let piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.Empty;
                if (row === 6) {
                    piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.WhitePawn;
                }
                if (row === 1) {
                    piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.BlackPawn;
                }
                if (row === 0) {
                    if (col === 0 || col === 7) {
                        piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.BlackRook;
                    } else if (col === 1 || col === 6) {
                        piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.BlackKnight;
                    } else if (col === 2 || col === 5) {
                        piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.BlackBishop;
                    } else if (col === 3) {
                        piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.BlackQueen;
                    } else if (col === 4) {
                        piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.BlackKing;
                    }
                }
                if (row === 7) {
                    if (col === 0 || col === 7) {
                        piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.WhiteRook;
                    } else if (col === 1 || col === 6) {
                        piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.WhiteKnight;
                    } else if (col === 2 || col === 5) {
                        piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.WhiteBishop;
                    } else if (col === 3) {
                        piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.WhiteQueen;
                    } else if (col === 4) {
                        piece = _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.WhiteKing;
                    }
                }
                newRow.push({
                    id: row * 8 + col,
                    piece,
                    isHighlighted: false
                });
            }
            squares.push(newRow);
        }
        setBoard(squares);
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_dnd_kit_core__WEBPACK_IMPORTED_MODULE_2__.DndContext, {
        onDragEnd: handleDragEnd,
        onDragStart: handleDragStart,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: (_styles_ChessBoard_module_css__WEBPACK_IMPORTED_MODULE_5___default().board),
            children: board.map((row, x)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_ChessBoard_module_css__WEBPACK_IMPORTED_MODULE_5___default()["board-row"]),
                    children: board[x].map(({ id , piece , isHighlighted  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Droppable__WEBPACK_IMPORTED_MODULE_3__["default"], {
                            id: id,
                            isHighlighted: isHighlighted,
                            children: piece === _Piece__WEBPACK_IMPORTED_MODULE_4__.ChessPieces.Empty ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Piece__WEBPACK_IMPORTED_MODULE_4__["default"], {
                                id: id,
                                type: piece
                            })
                        }, id))
                }, x))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ChessBoard);


/***/ }),

/***/ 5345:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _dnd_kit_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3831);
/* harmony import */ var _dnd_kit_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_dnd_kit_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_ChessBoard_module_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1099);
/* harmony import */ var _styles_ChessBoard_module_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_styles_ChessBoard_module_css__WEBPACK_IMPORTED_MODULE_3__);




const Droppable = ({ id , children , isHighlighted  })=>{
    const { setNodeRef  } = (0,_dnd_kit_core__WEBPACK_IMPORTED_MODULE_2__.useDroppable)({
        id
    });
    const isDarkSquare = (Math.floor(id / 8) + id % 8) % 2 !== 0;
    const baseClassName = isDarkSquare ? (_styles_ChessBoard_module_css__WEBPACK_IMPORTED_MODULE_3___default().darkSquare) : (_styles_ChessBoard_module_css__WEBPACK_IMPORTED_MODULE_3___default().lightSquare);
    const highlightedClassName = isDarkSquare ? (_styles_ChessBoard_module_css__WEBPACK_IMPORTED_MODULE_3___default().darkSquareHighlighted) : (_styles_ChessBoard_module_css__WEBPACK_IMPORTED_MODULE_3___default().lightSquareHighlighted);
    const className = isHighlighted ? highlightedClassName : baseClassName;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: setNodeRef,
        className: className,
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Droppable);


/***/ })

};
;