exports.id = 99;
exports.ids = [99];
exports.modules = {

/***/ 1099:
/***/ ((module) => {

// Exports
module.exports = {
	"board": "ChessBoard_board__K9wV_",
	"board-row": "ChessBoard_board-row__JS7Rt",
	"piece-image": "ChessBoard_piece-image__axQpk",
	"square": "ChessBoard_square__Mo36r",
	"lightSquare": "ChessBoard_lightSquare__IVivK ChessBoard_square__Mo36r",
	"lightSquareHighlighted": "ChessBoard_lightSquareHighlighted___sC6w ChessBoard_square__Mo36r",
	"darkSquare": "ChessBoard_darkSquare__D6D3t ChessBoard_square__Mo36r",
	"darkSquareHighlighted": "ChessBoard_darkSquareHighlighted__q4PGS ChessBoard_square__Mo36r",
	"piece": "ChessBoard_piece__EFffe",
	"wP": "ChessBoard_wP__tfPra",
	"wR": "ChessBoard_wR__U6iWv",
	"wN": "ChessBoard_wN__7zaNH",
	"wB": "ChessBoard_wB__lknv_",
	"wQ": "ChessBoard_wQ__BeCiv",
	"wK": "ChessBoard_wK___m3TF",
	"bP": "ChessBoard_bP__Zcj01",
	"bR": "ChessBoard_bR__1Zxxm",
	"bN": "ChessBoard_bN__d6dfR",
	"bB": "ChessBoard_bB__zL422",
	"bQ": "ChessBoard_bQ__XBVJz",
	"bK": "ChessBoard_bK__f0cxE"
};


/***/ })

};
;