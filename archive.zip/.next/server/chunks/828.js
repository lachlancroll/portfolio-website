exports.id = 828;
exports.ids = [828];
exports.modules = {

/***/ 3005:
/***/ ((module) => {

// Exports
module.exports = {
	"projects": "Projects_projects__QAtwy",
	"chess": "Projects_chess__yCGn6",
	"board": "Projects_board__HxEnE",
	"content": "Projects_content__RrrN_"
};


/***/ }),

/***/ 8828:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _styles_Projects_module_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3005);
/* harmony import */ var _styles_Projects_module_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_Projects_module_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _chess_Chess__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3529);



const Projects = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: (_styles_Projects_module_css__WEBPACK_IMPORTED_MODULE_2___default().projects),
        id: "about",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                children: "<Projects>"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                children: "Chess"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_styles_Projects_module_css__WEBPACK_IMPORTED_MODULE_2___default().chess),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        className: (_styles_Projects_module_css__WEBPACK_IMPORTED_MODULE_2___default().content),
                        children: [
                            "this doesn't currently work on my website, but it does on my github so check it out here: ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                href: "https://github.com/lachlancroll/Chess",
                                children: "https://github.com/lachlancroll/Chess"
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_chess_Chess__WEBPACK_IMPORTED_MODULE_1__["default"], {}),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_styles_Projects_module_css__WEBPACK_IMPORTED_MODULE_2___default().content),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "This project uses Javascript (with the p5 library), and Java. it uses AWS Elastic Beanstalk to host the RESTful web service which was made using Spring Boot. The AI uses a minimax algorithm with alpha beta pruning."
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Projects);


/***/ })

};
;