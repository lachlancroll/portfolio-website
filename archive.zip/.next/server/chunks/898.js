"use strict";
exports.id = 898;
exports.ids = [898];
exports.modules = {

/***/ 3898:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ About)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./src/styles/About.module.css
var About_module = __webpack_require__(1247);
var About_module_default = /*#__PURE__*/__webpack_require__.n(About_module);
// EXTERNAL MODULE: ./src/pages/about/background/Background.tsx
var Background = __webpack_require__(5502);
;// CONCATENATED MODULE: ./src/images/github-icon.png
/* harmony default export */ const github_icon = ({"src":"/_next/static/media/github-icon.69040d2e.png","height":560,"width":560,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAgVBMVEX5+/v4+/vr7e3q7Ozp6+vo6urn6enm6Ojf4eHe4ODd39/m6Ojl5+fa3Nzn6enj5eXm6Ojk5ubm6Ojl5+fl5+fl5+fm6Ojn6enm6Ojn6enn6Ojn6enn6enn6enn6enm6Ojn6enn6enn6enn6enn6enn6enn6enn6enn6enn6enn6enSLKskAAAAKnRSTlMAAAAAAAAAAAAAAAEBAQIFBggKDRggJSwsNDs/h4iJio6Sobq7vOfp6u7Ix/MvAAAASElEQVR42gVACRZAIBD9lmnsW3YhInL/A3rIEvJAcYbYX53b/AikL6WMJtR2FGKwNeSzsJheCTrutv9OAjd7N5uSUXBQ5SGnP6a5BLJt2ORfAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/pages/about/About.tsx






const AboutMePage = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (About_module_default()).hero,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Background["default"], {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (About_module_default()).content,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (About_module_default()).text,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "<I'm Lachlan>"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "check out my projects"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "below and/or on my Github"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "https://github.com/lachlancroll",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: github_icon.src,
                                alt: "Github logo",
                                width: "100",
                                height: "100"
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const About = (AboutMePage);


/***/ }),

/***/ 5502:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var seedrandom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6621);
/* harmony import */ var seedrandom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(seedrandom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Row__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2256);



const Background = ()=>{
    const rng = seedrandom__WEBPACK_IMPORTED_MODULE_1___default()("myseed");
    const listArray = [];
    for(let i = 0; i < 50; i++){
        const random = Math.floor(rng() * 9);
        const random2 = Math.floor(rng() * 9);
        let index;
        index = i;
        listArray.push(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Row__WEBPACK_IMPORTED_MODULE_2__["default"], {
            index: i,
            space: random,
            codeDropSize: random2
        }, i));
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: listArray
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Background);


/***/ })

};
;